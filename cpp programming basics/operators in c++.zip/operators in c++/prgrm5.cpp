#include<iostream>
using namespace std;
int main()
{
    int greater,a,b;
    cout<<"enter 2 nos : ";
    cin>>a>>b;
    cout<<"sum of 2 nos : "<<a+b;
    cout<<"difference of 2 nos : "<<a-b;
}
