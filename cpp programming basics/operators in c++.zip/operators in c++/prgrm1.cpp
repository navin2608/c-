#include<iostream>
using namespace std;
int main()
{
    int a,b,c,d,e,av;
    cout<<"enter 5 nos";
    cin>>a>>b>>c>>d>>e;
    cout<<((a+b+c+d+e)/5);
}

