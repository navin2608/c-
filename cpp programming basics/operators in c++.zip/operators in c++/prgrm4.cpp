#include<iostream>
using namespace std;
int main()
{
    int greater,a,b;
    cout<<"enter 2 nos : ";
    cin>>a>>b;
    (a>b)?greater=a:greater=b;
    cout<<"greater no : "<<greater;
}
