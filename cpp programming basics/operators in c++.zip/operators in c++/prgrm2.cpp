#include<iostream>
using namespace std;
int main()
{
    int a;
    cout<<"enter a no:";
    cin>>a;
    cout<<a++;
    cout<<"\n"<<++a;
}

