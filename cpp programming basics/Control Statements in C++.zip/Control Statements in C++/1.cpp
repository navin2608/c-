#include<iostream>
using namespace std;
int main(){
	unsigned int seconds;
	int h,m,s;
	cout<<"Enter the time in seconds : ";
	cin>>seconds;
	h=seconds/3600;
	m=(seconds-(3600*h))/60;
	s=(seconds-(3600*h)-(m*60));
	cout<<"Time is " <<h<<" hrs "<<m <<" mins " <<s<<" secs\n";
return 0;
}
