#include<iostream>
using namespace std;
int main(){
	int num,i,j,k;
	cout<<"How many rows are to be printed";
	cin>>num;
	for(i=1;i<=num;i++){
		for(j=1;j<=num-i;j++){
			cout<<" ";
		}
		for(k=1;k<=2*i-1;k++){
			cout<<"*";
		}
		cout<<endl;
	}
	return 0;
}

