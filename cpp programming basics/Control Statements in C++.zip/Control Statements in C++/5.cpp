#include<iostream>
using namespace std;
int main(){
	int num,temp,sum=0;
	cout<<"Enter the number to reverse: ";
	cin>>num;
	while(num!=0){
		temp=num%10;
		sum=(sum*10)+temp;
		num=num/10;
	}
	cout<<"Reverse of entered number is: "<<sum;
	return 0;
}

