#include<iostream>
using namespace std;
int main(){
	int num,revnum,temp,t,sum=0;
	cout<<"If input number is";
	cin>>num;
	temp=num;
	while(num!=0){
		t=num%10;
		sum=(sum*10)+t;
		num=num/10;
	}
	if(sum==temp){
		cout<<temp<<" is a palindrome";
	}
	else{
		cout<<temp<<" is not a palindrome";
	}
	return 0;
}

