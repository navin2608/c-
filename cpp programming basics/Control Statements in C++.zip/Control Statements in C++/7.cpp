#include<iostream>
using namespace std;
int main(){
	int num,t=0;
	cout<<"Enter a number";
	cin>>num;
	for(int i=2;i<=num/2;i++){
		if(num%i==0){
			t=1;
			break;
		}
	}
	if(num==1 || num==0){
		cout<<num<<" is neither prime nor composite";
	}
	else{
		if(t==0){
			cout<<num<<" is a prime number";
		}
		else{
			cout<<num<<" is not a prime number";
		}
	}
	return 0;
}

