#include<iostream>
using namespace std;
int main(){
	int amount;
	cin>>amount;
	cout<<"Cashier gives you "<<(amount/10)<<" currency notes of 10"<<endl;
	cout<<"OR"<<endl;
	cout<<(amount/50)<<" currency notes of 50"<<endl;
	cout<<"OR"<<endl;
	cout<<(amount/100)<<" currency notes of 100"<<endl;
	return 0;
}

