#include<iostream>
using namespace std;
int main(){
	int num,i,j,k;
	char ch;
	cin>>num>>ch;
	for(i=1;i<=num;i++){
		for(j=1;j<=num-i;j++){
			cout<<" ";
		}
		for(k=1;k<=2*i-1;k++){
			cout<<ch;
		}
		cout<<endl;
	}
	return 0;
}
