#include<iostream>
using namespace std;
int main(){
	int num;
	cin>>num;
	if(num>0){
		cout<<num<<" is a positive number";
	}
	else if(num==0){
		cout<<num<<" is neither negative or positive";
	}
	else{
		cout<<num<<" is a negative number";
	}
	return 0;
}

