#include<iostream>
using namespace std;
int main(){
	int num,temp,sum=0;
	cout<<"Enter a number : ";
	cin>>num;

	while( num != 0)
		{
			temp = num % 10;
			temp = temp + 1;
			if(temp == 10)
				temp = 0;
			num = num / 10;
			sum = ( sum * 10 ) + temp;
		}
	num = 0;
	while( sum != 0)
		{
			temp = sum % 10;
			sum = sum / 10;
			num = ( num * 10 ) + temp;
		}
	cout<<num;
return 0;
}

