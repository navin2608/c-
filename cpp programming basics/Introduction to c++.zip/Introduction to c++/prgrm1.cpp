#include<iostream>
using namespace std;
int main()
{
    string screen="Welcome to Wipro";
    cout<<screen;
}
