#include<iostream>
using namespace std;
int main()
{
    float a,b,c;
    cout<<"enter 3 floating point nos";
    cin>>a>>b>>c;
    cout<<"enter nos are\n";
        cout<<a<<"\n"<<b<<"\n"<<c;

}

