#include<iostream>
using namespace std;
int main()
{
    int a,b,c;
    cout<<"enter 3 nos";
    cin>>a>>b>>c;
    cout<<a<<"\n"<<b<<"\n"<<c;
}

