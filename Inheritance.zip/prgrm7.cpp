Base Class							Derived Class						Public/Private:

class Student						class University					Private
A derived class University doesn't need to have all the details of class Student.

class Person						class Student						Public
A derived classs Student should have access to class Person.

class Beverages						class Coffee						Public
A derived class Coffee should have access to class Beverages.

class Coffee						class Breakfast						Private
A derived class Breakfast doesn't need to have all the details of class Coffee.