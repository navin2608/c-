#include <iostream>

using namespace std;

class Vehicles
{
    
};
class FourWheeles: public Vehicles
{
    
};
class Cars: public FourWheeles
{
    
};
class SUV: public Cars
{
    
};
class Sedan: public Cars
{
    
};

int main()
{
    
    return 0;
}
