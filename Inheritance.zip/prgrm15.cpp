#include <iostream>

using namespace std;

class A  
{
    public: 
    void display()
    {  
        cout<<"A::display";  
    } 
    
};
class D : public A 
{
    public:
    void display()
    {  
        cout<<"D::display"; 
    } 
};

int main()
{
    D d;
    d.display();

    return 0;
}

Output:
D::display

d.display() doesn't invoke A::display().
To invoke A::display() we'll use base class pointer for early bidding.
The int main() should be as follows:

int main()
{
    A *a;
    D d;
    a = &d;
    a->display();

    return 0;
}

Output:
A::display