#include <iostream>

using namespace std;

class Time
{
    public:
    int hour, minute, second;
    public:
    int hr_to_min()
    {
        cin>>hour;
        minute=hour*60;
        cout<<"hrs to min conversion is"<<minute;
    }
    int hr_to_sec()
    {
        cin>>hour;
        second=hour*60*60;
        cout<<"hrs to sec conversion is"<<second;
    }
};

class Logintime: private Time
{
    
};

int main()
{
    Logintime t;
    t.hr_to_min();
    t.hr_to_sec();
    return 0;
}

An object of Logintime can't access hr_to_min and hr_to_sec as they are inaccessible to Logintime class because the parent class is private.