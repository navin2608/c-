#include <iostream>

using namespace std;
class Sample
{
    public:
    int intdata;
    string stringdata;
    public:
    void store()
    {
        cout<<"Enter int data "<<endl;
        cin>>intdata;
        cout<<"Enter string data "<<endl;
        cin>>stringdata;
    }
    void characterAt()
    {
        int i;
        cout<<"Enter index ";
        cin>>i;
        char ch=(char)(stringdata[i]);
        cout<<"Character at index "<<i<<" is "<<ch<<endl;
    }
    void reverse()
    {
        int temp=intdata;
        int rev=0;
        while(temp!=0)
        {
            int r=temp%10;
            rev=(rev*10)+r;
            temp=temp/10;
        }
        cout<<"Reverse value is "<<rev<<endl;
    }
    void retrieve()
    {
        cout<<"Orignal Value"<<endl;
        cout<<stringdata<<endl;
        cout<<intdata<<endl;
    }
};
int main()
{
    Sample s;
    s.store();
    s.characterAt();
    s.reverse();
    s.retrieve();
    return 0;
}