Der1

Member										Access Modifier
pub_base_fun()								public
int prot_var								protected
prot_base_fun()								protected
int priv_base_var							not accessible (private member)

pub_der1_fun()								public
int prot_var								protected
prot_der1_fun()								protected
int priv_der1_var							private

Der2

Member										Access Modifier
pub_base_fun()								public
int prot_var								protected
prot_base_fun()								protected
int priv_base_var							not accessible (private member)

pub_der2_fun()								public
int prot_var								protected
prot_der2_fun()								protected
int priv_der2_var							private

