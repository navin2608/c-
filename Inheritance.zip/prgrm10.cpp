#include <iostream>

using namespace std;

class Base{
    public:
    Base (int i): prot(i)
    { }
    protected:
    int prot;
};
class Der1 : public Base
{
    Der1 (int j): prot(j)
    { }
};
class Der2 : public Base
{
    Der2 (int k): Base(k)
    { }
};
class Der3 : public Base
{
    Der3()
    { }
};

int main()
{
    cout<<"Valid Constructor";

    return 0;
}

Only Der2(int k): Base(k) { } is a valid constructor. In the first constructor named Der1 there is no field named prot and in the third constructor name Der3
there is no function to call Base.