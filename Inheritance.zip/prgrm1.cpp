1) Number, Integer, FloatingPoint, Scientific, Fixed

#include <iostream>

using namespace std;

class Number
{

};
class Integer: public Number
{
    
};
class FloatingPoint: public Number
{
    
};
class Scientific: public FloatingPoint
{
    
};
class Fixed: public FloatingPoint
{
    
};

int main()
{
    

    return 0;
}


2) Animal, Domestic, Dog, Dalmation

#include <iostream>

using namespace std;

class Animal
{

};
class Domestic: public Animal
{
    
};
class Dog: public Domestic
{
    
};
class Dalmation: public Dog
{
    
};

int main()
{
   

    return 0;
}

3) Furniture, Table, DiningTable, RoundShapedTable, RectangleShapedTable

#include <iostream>

using namespace std;

class Furniture
{

};
class Table: public Furniture
{
    
};
class DiningTable: public Table
{
    
};
class RectangleShapedTable: public Table
{
    
};
class RoundShapedTable: public Table
{
    
};

int main()
{
    

    return 0;
}

4) StorageDevices, Floppy, CD, MemoryStick

#include <iostream>

using namespace std;

class StorageDevices
{

};
class Floppy: public StorageDevices
{
    
};
class CD: public StorageDevices
{
    
};
class MemoryStick: public StorageDevices
{
    
};

int main()
{
    

    return 0;
}
