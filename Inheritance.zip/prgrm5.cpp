#include <iostream>

using namespace std;

class Vehicles
{
    public:
    Vehicles()
    {
        cout<<"Vehicles are further divided into:\n";
    }
    ~Vehicles()
    {
        cout<<"Destructor for Vehicles\n";
    }
};
class FourWheelers: public Vehicles
{
    public:
    FourWheelers()
    {
        cout<<"FourWheelers is a type of vehicles\n";
    }
    ~FourWheelers()
    {
        cout<<"Destructor for FourWheelers\n";
    }
};
class Cars: public FourWheelers
{
    public:
    Cars()
    {
        cout<<"Cars are the most common types of four wheelers\n";
    }
    ~Cars()
    {
        cout<<"Destructor for Cars\n";
    }
};
class SUV: public Cars
{
    public:
    SUV()
    {
        cout<<"I like SUV more as they are spacious\n";
    }
    ~SUV()
    {
        cout<<"Destructor for SUV\n";
    }
};
class Sedan: public Cars
{
    public:
    Sedan()
    {
        cout<<"Sedans are more classy\n";
    }
    ~Sedan()
    {
        cout<<"Destructor for Sedan\n";
    }
};

int main()
{
    SUV obj1;
    cout<<endl;
    Sedan obj2;
    cout<<endl;
    
    
    return 0;
}

Order:
Vehicles get executed first then the FourWheelers after which Cars gets executed and then SUV as it is called first.
Same is for Sedan. Sedan gets executed at last inplace of SUV.
Destructors are executed in the reverse order.
From Sedan->Cars->FourWheelers->Vehicles. 
From SUV->Cars->FourWheelers->Vehicles.