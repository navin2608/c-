#include <iostream>
#define pi 3.14159265358979323846

using namespace std;

class Shape
{
    public:
    int x,y;
    
    void computearea(int a, int b)
    {
        x = a;
        y = b;
        cout<<"The dimensions of shape are: "<<x<<" and "<<y<<endl;
    }
};
class Rectangle : public Shape
{
    public:
    void computearea(int c, int d)
    {
        x = c;
        y = d;
        cout<<"Area of Rectangle is "<<(x*y)<<endl;
    }
};
class Square : public Shape
{
    public:
    void computearea(int c)
    {
        x = c;
        y = c;
        cout<<"Area of Square is "<<(x*y)<<endl;
    }
};
class Circle : public Shape
{
    public:
    void computearea(int c)
    {
        x = c;
        y = c;
        cout<<"Area of Circle is "<<(pi*x*y)<<endl;
    }
};

int main()
{
    Rectangle r;
    Square sq;
    Circle c;
    r.computearea(5,6);
    sq.computearea(10);
    c.computearea(8);
    

    return 0;
}
