#include <iostream>

using namespace std;

class A 
{
    public:
    void display()  
    { 
        cout<<"A::display()"; 
    }
    void display(int t) 
    { 
        cout<<"A::display(int ) : "<<t<<endl;  
    }
};
class D : public A
{
    public:
    void display()  
    { 
        cout<<"D::display ()"; 
    }
};

int main()
{
    D d;
    d.display();

    return 0;
}

Statement d.display() is correct and gives output: D::display ()

Statement d.display(10) is incorrect because there is no function in class D for call to D::display(int) i.e. there is no parameterized function in 
class D to call.
Instead use early bidding to call the function in class A which requires a parameter.

 int main()
{
    D d;
    A *a;
    a = &d;
    a->display(10);
    return 0;
}

If above int main() is used then the output will be:
A::display(int ) : 10