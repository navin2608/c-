#include<iostream>

using namespace std;

class Base
{
    private:
    int x;
    public:
    Base() 
    {
        x = 0;
    }
    Base(int p1) 
    {
        x=p1;
    }
    void show()
    {
        cout<<x;
    }
};

int main()
{
    Base b;
    Base b2(7);
    b.show();
    cout<<endl;
    b2.show();
   
}