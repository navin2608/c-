#include <iostream>

using namespace std;

class Person
{
    public:
    string name;
    int age;
    string address;
    Person(string namep, int agep, string addp)
    {
        name = "saga";
        age = 12;
        address = "112/2354";
        cout<<"Name is: "<<name<<"\nAge is: "<<age<<"\nAddress is: "<<address<<endl;
    }
    ~Person()
    {
        cout<<"Destructor called"<<endl;
    }
};
class Student: public Person
{
    public:
    int year;
    string course;
    string colgname;
    Student(string crse, int yr, string colgn):Person(crse, yr, colgn)
    {
        year = yr;
        course = crse;
        colgname = colgn;
        cout<<"Year is: "<<year<<"\nCourse is: "<<course<<"\nCollege names is: "<<colgn<<endl;
    }
    ~Student()
    {
        cout<<"Destructor called"<<endl;
    }
};
class Employee: public Person
{
    public:
    int empnum;
    string doj;
    string salary;
    Employee(string date, int n, string sal):Person(date, n, sal)
    {
        empnum = n;
        doj = date;
        salary = sal;
        cout<<"Employee number is: "<<empnum<<"\nDate of joining is: "<<doj<<"\nSalary is: "<<salary<<endl;
    }
    ~Employee()
    {
        cout<<"Destructor called"<<endl;
    }
};
class Participant
{
    public:
    string names;
    Participant(string nameinst)
    {
        names=nameinst;
    }
    void operator =(string n)
    {
        names=n;
    }
    void getname()
    {
        cout<<names<<endl;
    }
    ~Participant()
    {
        cout<<"Destructor called"<<endl;
    }
};

int main()
{
    Student s=Student("btech",4,"SRM");
    Employee e=Employee("01-07-2020",1,"5600.34");
    Participant p1("Rahul");
    Participant p2("Arjun");
    p1=p2;
    p1.getname();
    return 0;
}
