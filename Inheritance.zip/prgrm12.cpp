#include<iostream>

using namespace std;

class Person
{
    public:
    string name;
    Person(string n)
    {
        name=n;
        cout<<name<<endl;
    }
    string getname(string n)
    {
        return n;
    }
};
class Participant: public Person
{
    public:
    string desig;
    Participant(string des): Person(des)
    {
       desig=des;
    }
};
int main()
{
    Person p("Varun");
    Participant p1("Student");
    
    return 0;
}

Constructors are not inherited. They are called implicitly or explicitly by the child constructors.