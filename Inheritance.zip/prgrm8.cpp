Classes Manager and Employee.

Employee should be the base class and Manager should be the derived class as if a Manager is truly a "kind of" Employee,
then it should have all the things (i.e., the same interface) that an Employee has.

The relationship that exists between them is a "is-a" relationship.

#include <iostream>

using namespace std;

class Employee
{
    public:
    string name;
    int age;
    int empid;
    Employee()
    {
        name = "Raj";
        age = 22;
        empid = 2321;
        cout<<"Employee name is: "<<name<<endl;
        cout<<"Employee age is: "<<age<<endl;
        cout<<"Employee id is: "<<empid<<endl;
    }
    ~Employee()
    {
        cout<<"Destructor1"<<endl;
    }
};
class Manager: public Employee
{
    public:
    string desig;
    float salary;
    Manager(string des, float sal)
    {
        desig = des;
        salary = sal;
        cout<<"Designation of employee is "<<desig<<" and salary is "<<salary<<endl;
    }
    ~Manager()
    {
        cout<<"Destructor2"<<endl;
    }
};

int main()
{
    Manager m("Manager", 3600.00);

    return 0;
}
