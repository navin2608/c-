#include <iostream>

using namespace std;

class Shape
{
    public:
    int x,y;
    
    void computearea(int a, int b)
    {
        x = a;
        y = b;
        cout<<"The dimensions of shape are: "<<x<<" and "<<y<<endl;
    }
};

int main()
{
    Shape s;
    s.computearea(5,10);

    return 0;
}
