#include<iostream>
#include<math.h>
#include<stdlib.h>
using namespace std;

int Rule1(int b[],int n);
int Rule2(int n);
int Rule3(int c[],int n);
int Rule4(int c[],int n);
int Rule5(int b[],int n);
int arrayCleanup(int a[],int n);
//main
int main()
{
    int n;
    cout<<"Enter size of Array\n";
    cin>>n;
    cout<<"Enter array elements\n";
    int a[n];
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    
    n = sizeof(a)/sizeof(a[0]);
    arrayCleanup(a,n);
	return 0;
}


//Rule 1
int Rule1(int b[],int n){
	int c[n],count=0;
	for(int i=0;i<n;i++){
		int flag=0;
		for(int j=i+1;j<n;j++){
			if(b[i]==b[j]||b[i]==0){
				flag=1;
				break;
			}
		}
		if(flag==0){
			c[count]=b[i];
			count++;
		}
	}
	Rule3(c,count);
	return 0;
}

//Rule 2
int Rule2(int n){
	int key=0;
	while(n>0 || key>9){
		if(n==0){
			n=key;
			key=0;
		}
		key=key+(n%10);
		n=n/10;
	}
	return key;
}

//Rule 3
int Rule3(int c[],int n){
	int b[n],count=0;
	for(int i=0;i<n;i++){
		if(c[i]!=0){
			b[i]=c[i];
			count++;
		}
	}
	Rule4(b,count);
}

//Rule 4
int Rule4(int c[],int n){
	int k[100];
	int size=0;
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			k[size]=c[i]+c[j];
			size++;
		}
	}
	int l[n];
	int z=0;
	for(int i=0;i<n;i++){
		int flag=0;
		for(int j=0;j<size;j++){
			if(c[i]==k[i]){
				flag=1;
				break;
			}
		}
		if(flag==0){
			l[z]=c[i];
			z++;
		}
	}
	Rule5(l,z);
	return 0;
}

//Rule 5
int Rule5(int l[],int n){
    int sq[10];
    int p=0;
    for(int i=0;i<n;i++){
		int f=sqrt(l[i]);
        if(f!=1){
            sq[i]=f;
            p+=1;
        }
    }
    int res[10];
    int fin=0;
    
    for (int i=0;i<n;i++){
        int flag=1;
        for(int j=0;j<p;j++){
            if(l[i]==sq[j]){
                flag=0;
                break;
            }
        }
        if(flag==1){
            res[fin]=l[i];
            fin++;
        }
    }
    for(int i=0;i<fin;i++){
        cout<<res[i]<<endl;
    }
    return 0;
}

//ArrayCleanUp
int arrayCleanup(int a[],int n) {
    int b[n];
    for(int i=0;i<n;i++)
    {
        if(a[i]<10)
        {
            b[i]=a[i];
        }
        else
        {
            int n=Rule2(a[i]);
            b[i]=n;
        }    
    }
    Rule1(b,n);
    return 0;
}

