#include<iostream>
using namespace std;
void identifyHeavy(int input1[3][3]);
int main(){
	int input1[3][3],i,j;
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			cin>>input1[i][j];
		}
	}
	identifyHeavy(input1);
	return 0;
}

void identifyHeavy(int input1[3][3]){
	int output1;
	int corner=input1[0][0]+input1[0][2]+input1[2][2]+input1[2][0];
	int centre=input1[0][1]+input1[1][2]+input1[2][1]+input1[1][0];
	if(corner>centre)
		output1=1;
	else if(corner<centre)
		output1=2;
	else
		output1=3;
cout<<output1;
}
