#include<iostream>
using namespace std;
int checkPrime(int a);
int main(){
	int num1,num2,i;
	cout<<"Enter two positive integers: \n";
	cin>>num1>>num2;
	cout<<"Prime numbers between "<<num1<<" and "<<num2<<" are:";
	for(i=num1;i<=num2;i++){
		if(checkPrime(i)==1){
			cout<<i<<" ";
		}
	}
	return 0;
}

int checkPrime(int a){
	int i,flag=0;
	for(i=2;i<=a/2;i++){
		if(a%i==0){
			flag=1;
		}
	}
	if(flag == 0)
		return 1;
	else
		return 0;
}
