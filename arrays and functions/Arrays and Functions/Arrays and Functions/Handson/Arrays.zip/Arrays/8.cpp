#include<iostream>
using namespace std;
int main(){
	int arr[5],i,j,k,temp,sum;
	cout<<"Enter the elements of the array:\n";
	for(i=0;i<5;i++){
		cin>>arr[i];
	}
//sort the array
	for(i=0;i<5;i++){
		for(j=i+1;j<5;j++){
			if(arr[i]>arr[j]){
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	temp=0;
	for(i=0;i<5;i++){
		for(j=0;j<5;j++){
			sum=arr[i]+arr[j];
				for(k=0;k<5;k++){
					if(sum!=arr[k]){
						temp=arr[k];
						break;
					}
				}
		}
	}
	cout<<"Smallest element is "<<temp;
	return 0;
}

