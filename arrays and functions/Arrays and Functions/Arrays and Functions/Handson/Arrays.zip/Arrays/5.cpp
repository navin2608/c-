#include<iostream>
using namespace std;
int main(){
	int size,arr[100],i,j,temp;
	cout<<"Enter the number of elements of the array\n";
	cin>>size;
	cout<<"Enter the numbers\n";
	for(i=0;i<size;i++){
		cin>>arr[i];
	}
	for(i=0;i<size;i++){
		for(j=i+1;j<size;j++){
			if(arr[i]>arr[j]){
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	cout<<"The numbers arranged in ascending order are given below\n";
	for(i=0;i<size;i++){
		cout<<arr[i]<<endl;
	}
	return 0;
}

