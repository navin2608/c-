#include<iostream>
#include<iomanip>
using namespace std;
int main(){
	int arr[100],i,sum=0,num;
	float avg;
	cout<<"Enter the Size of an array "<<endl;
	cin>>num;
	cout<<"Enter "<<num<<" numbers";
	for(i=0;i<num;i++){
		cin>>arr[i];
	}
	for(i=0;i<num;i++){
		sum=sum+arr[i];
	}
	avg=(float)sum/(float)num;
	cout<<"Sum of all elements in the array is "<<sum;
	cout<<"Average of all input numbers = "<<setprecision(2)<<avg;
	return 0;
}
