#include<iostream>
using namespace std;
int main(){
	int i,j,row,col,mat[10][10];
	cout<<"Enter the number of rows and columns of matrix "<<endl;
	cin>>row>>col;
	cout<<"Enter the elements of matrix\n";
	for(i=0;i<row;i++){
		for(j=0;j<col;j++){
			cin>>mat[i][j];
		}
	}
	cout<<"Entered matrix is \n";
	for(i=0;i<row;i++){
		for(j=0;j<col;j++){
			cout<<mat[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<"Transpose of entered matrix is \n";
	for(i=0;i<col;i++){
		for(j=0;j<row;j++){
			cout<<mat[j][i]<<" ";
		}
		cout<<endl;
	}
	return 0;
}

