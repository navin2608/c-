#include<iostream>
using namespace std;
int main(){
	int i, num[100],size,find;
	cout<<"Enter the size of the array ";
	cin>>size;
	cout<<"Enter the elements of array: ";
	for(i=0;i<size;i++){
		cin>>num[i];
	}
	cout<<"Enter the element to search: ";
	cin>>find;
	for(i=0;i<size;i++){
		if(find==num[i]){
			cout<<"***Element "<<find<<" found and its index is "<<i<<"***";
			break;
		}
		if(i==size-1 && find!=num[i]){
			cout<<"!!!Element not Found!!!";
		}
	}
	
	return 0;
}


