#include<iostream>
using namespace std;
int main(){
	int arr[20],count=0,sum=0,i;
	cout<<"Enter the 20 elements for the array";
	for(i=0;i<20;i++){
		cin>>arr[i];
	}
	for(i=0;i<20;i++){
		if(arr[i]%2==0){
			count++;
			sum=sum+arr[i];
		}
	}
	cout<<"Count of even numbers is "<<count<<endl;
	cout<<"Sum of values of all even number elements is "<<sum<<endl;
	return 0;
}

